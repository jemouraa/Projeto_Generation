package com.humanae.humanae;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HumanaeApplication {

	public static void main(String[] args) {
		SpringApplication.run(HumanaeApplication.class, args);
	}

}
